import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report

# Load dataset
df = pd.read_csv("comments.csv")

# 1. CLEANING
df.columns = df.columns.str.strip().str.replace(" ", "_").str.lower()

df.rename(columns={
    'user__id': 'user_id',
    'photo_id': 'photo_id',
    'created_timestamp': 'created_timestamp',
    'posted_date': 'posted_date',
    'emoji_used': 'emoji_used',
    'hashtags_used_count': 'hashtag_count'
}, inplace=True)

df['created_timestamp'] = pd.to_datetime(df['created_timestamp'], errors='coerce')
df['comment_length'] = df['comment'].astype(str).apply(len)

# 2. EXPLORATORY DATA ANALYSIS

plt.figure(figsize=(6, 4))
sns.countplot(data=df, x='emoji_used', palette='Set2')
plt.title("Emoji Usage in Comments")
plt.xlabel("Used Emoji?")
plt.ylabel("Number of Comments")
plt.savefig("emoji_usage.png")
plt.close()

plt.figure(figsize=(6, 4))
sns.histplot(df['hashtag_count'], bins=20, kde=True, color='skyblue')
plt.title("Distribution of Hashtag Counts")
plt.xlabel("Hashtag Count")
plt.ylabel("Frequency")
plt.savefig("hashtag_distribution.png")
plt.close()

plt.figure(figsize=(7, 5))
sns.scatterplot(data=df, x='comment_length', y='hashtag_count', hue='emoji_used', alpha=0.6)
plt.title("Comment Length vs Hashtag Count")
plt.xlabel("Comment Length")
plt.ylabel("Hashtag Count")
plt.savefig("comment_vs_hashtag.png")
plt.close()

df['date'] = df['created_timestamp'].dt.date
daily_counts = df.groupby('date').size()
plt.figure(figsize=(10, 4))
daily_counts.plot()
plt.title("Daily Comment Activity")
plt.xlabel("Date")
plt.ylabel("Number of Comments")
plt.tight_layout()
plt.savefig("daily_comments.png")
plt.close()

# 3. MACHINE LEARNING - Predict Emoji Usage

df['emoji_used_binary'] = df['emoji_used'].map({'yes': 1, 'no': 0})

features = df[['hashtag_count', 'comment_length']].copy()
target = df['emoji_used_binary']

X_train, X_test, y_train, y_test = train_test_split(features, target, test_size=0.2, random_state=42)

model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

y_pred = model.predict(X_test)
report = classification_report(y_test, y_pred)
print("\n🧠 Emoji Usage Prediction Report:")
print(report)

# 4. SAVE CLEANED DATA
df.to_csv("instagram_cleaned.csv", index=False)
print("✅ Cleaned dataset saved as 'instagram_cleaned.csv'")
print("✅ Visualizations saved as PNG files.")
